package com.example.practice_10_glazirinnp_maliginaa;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Showlitem3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cocktail);
    }
}